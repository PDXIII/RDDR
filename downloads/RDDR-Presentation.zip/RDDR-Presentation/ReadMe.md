# RDDR-Presentation.key
### Redesign Design Radar Präsentation in Apple Keynote

Für den den reibungslosen Ablauf dieser Präsentation benötigt man __Keynote__ in der Version 6.2 (1861) erhältlich im [App Store](https://itunes.apple.com/de/app/keynote/id409183694?mt=12), sowie die Schrift __PT Sans Narrow__ in den Schnitten Regular und Bold erhältlich bei [Paratype](http://paratype.com/public/).

Viel Spaß und bitte nicht klauen!

Peter Sekan